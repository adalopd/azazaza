const mineflayer = require('mineflayer');
const fs = require('fs');

// Configuration
const serverIP = fs.readFileSync('server.txt', 'utf8').trim();
const masterUsername = fs.readFileSync('usermaster.txt', 'utf8').trim();
const approvedUsers = fs.readFileSync('userparty.txt', 'utf8').trim().split('\n').map(line => line.trim());
const credentials = fs.readFileSync('user.txt', 'utf8').trim().split('\n').map(line => {
  const [username, password] = line.trim().split(':');
  return { username, password };
});

let reconnectAttempts = {};
const maxReconnectAttempts = 5;

function randomDelay(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function createBot({ username, password }, botIndex) {
  const bot = mineflayer.createBot({
    host: serverIP,
    username,
    version: '1.8.9',
  });

  reconnectAttempts[username] = 0;

  bot.once('spawn', () => {
    console.log(`[${username}] Bot joined the server`);
    bot.chat(`/login ${password}`);
    detectAndFollowMaster(bot, username);
    randomPlayerActions(bot);
    blockDetectionAndJump(bot);
  });

  function detectAndFollowMaster(bot, username) {
    let lastLogTime = 0;
    const logInterval = 30000;

    setInterval(() => {
      const master = bot.players[masterUsername]?.entity;
      if (bot.entity.position.y < 5) {
        console.log(`[${username}] Below void threshold, jumping`);
        bot.setControlState('jump', true);
        setTimeout(() => bot.setControlState('jump', false), randomDelay(200, 500));
        return;
      }

      if (!master) {
        const currentTime = Date.now();
        if (currentTime - lastLogTime > logInterval) {
          console.log(`[${username}] ${masterUsername} not nearby`);
          lastLogTime = currentTime;
        }
        return;
      }

      const distance = bot.entity.position.distanceTo(master.position);
      if (distance > 100) {
        bot.setControlState('forward', false);
        bot.setControlState('sprint', false);
        return;
      } else if (distance > 1) {
        bot.lookAt(master.position.offset(0, master.height / 2, 0));
        setTimeout(() => {
          bot.setControlState('forward', true);
          bot.setControlState('sprint', true);
        }, randomDelay(100, 500));
      } else {
        bot.setControlState('forward', false);
        bot.setControlState('sprint', false);
      }
    }, 100 + randomDelay(50, 150));
  }

  function randomPlayerActions(bot) {
    setInterval(() => {
      if (Math.random() < 0.1) {
        bot.setControlState('jump', true);
        setTimeout(() => bot.setControlState('jump', false), randomDelay(200, 500));
      }

      if (Math.random() < 0.05) {
        bot.setControlState('sneak', true);
        setTimeout(() => bot.setControlState('sneak', false), randomDelay(1000, 3000));
      }

      if (Math.random() < 0.2) {
        const randomYaw = Math.random() * Math.PI * 2;
        const randomPitch = (Math.random() - 0.5) * Math.PI / 2;
        bot.look(randomYaw, randomPitch);
      }
    }, randomDelay(2000, 5000));
  }

  function blockDetectionAndJump(bot) {
    let isInVoid = false;

    setInterval(() => {
      const yaw = bot.entity.yaw;
      const forwardVector = {
        x: -Math.sin(yaw),
        z: Math.cos(yaw)
      };

      const forwardBlockPosition = bot.entity.position.offset(forwardVector.x, 0, forwardVector.z);
      const blockInFront = bot.blockAt(forwardBlockPosition);
      const blockBelow = bot.blockAt(bot.entity.position.offset(0, -1, 0));

      if (!blockBelow || blockBelow.name === 'air') {
        if (!isInVoid) {
          console.log(`[${bot.username}] Void detected, jumping`);
          isInVoid = true;
        }
        bot.setControlState('jump', true);
        setTimeout(() => bot.setControlState('jump', false), randomDelay(200, 500));
      } else {
        isInVoid = false;
      }

      if (blockInFront && blockInFront.boundingBox === 'block') {
        console.log(`[${bot.username}] Block ahead, jumping`);
        bot.setControlState('jump', true);
        setTimeout(() => bot.setControlState('jump', false), randomDelay(200, 500));
      }
    }, 100);
  }

  function sendHumanLikeChat(bot, message) {
    const typingSpeed = randomDelay(100, 300);
    message.split('').forEach((char, index) => {
      setTimeout(() => {
        bot.chat(message.slice(0, index + 1));
      }, typingSpeed * index);
    });
  }

  bot.on('message', (message) => {
    const messageText = message.toString().trim();

    if (
      messageText.includes('https://store.blocksmc.com') ||
      messageText.includes('https://discord.gg/') ||
      messageText.includes('Join our discord') ||
      messageText.includes('/Discord') ||
      messageText.includes('/Store') ||
      messageText === ''
    ) return;

    console.log(`[${bot.username}] Message: ${messageText}`);

    if (message.extra && message.extra[0] && message.extra[0].text.includes(masterUsername)) {
      console.log(`[${bot.username}] Master sent message. Executing /hub.`);
      bot.chat('/hub');
      return;
    }

    if (messageText.includes('New party request from') && messageText.includes('[ACCEPT]')) {
      const match = messageText.match(/New party request from (\w+)\. \[ACCEPT\]/);
      if (match) {
        const requester = match[1];
        if (approvedUsers.includes(requester)) {
          bot.chat(`/p accept ${requester}`);
          console.log(`[${bot.username}] Accepted party from ${requester}`);
        } else {
          console.log(`[${bot.username}] Ignored party request from ${requester}`);
        }
      }
    }
  });

  bot.on('error', (err) => {
    console.log(`[${bot.username}] Error: ${err}`);
    attemptReconnect({ username, password });
  });

  bot.on('end', () => {
    console.log(`[${bot.username}] Disconnected from server`);
    attemptReconnect({ username, password });
  });
}

function attemptReconnect({ username, password }) {
  if (reconnectAttempts[username] < maxReconnectAttempts) {
    reconnectAttempts[username]++;
    console.log(`[${username}] Attempting reconnect... (${reconnectAttempts[username]}/${maxReconnectAttempts})`);
    setTimeout(() => {
      createBot({ username, password });
    }, Math.pow(2, reconnectAttempts[username]) * 5000);
  } else {
    console.log(`[${username}] Max reconnect attempts reached. Giving up.`);
  }
}

// Spawn each bot with 5s delay
credentials.forEach((cred, i) => {
  setTimeout(() => {
    createBot(cred, i);
  }, i * 5000);
});
